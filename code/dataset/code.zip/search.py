# USAGE
# python search.py --index index.csv --query queries/103100.png --result-path dataset

# import the necessary packages
from pyimagesearch.colordescriptor import ColorDescriptor
from pyimagesearch.searcher import Searcher
import argparse
import cv2

"""# construct the argument parser and parse the arguments
ap = argparse.ArgumentParser()
ap.add_argument("-i", "--index", required = True,
	help = "Path to where the computed index will be stored")
ap.add_argument("-q", "--query", required = True,
	help = "Path to the query image")
ap.add_argument("-r", "--result-path", required = True,
	help = "Path to the result path")
args = vars(ap.parse_args())"""
class Retriever:
    def __init__(self,Query,IndexFile="index.csv",ColorDesc=(8, 12, 3)):
        # initialize the image descriptor
        cd = ColorDescriptor(ColorDesc)
        # load the query image and describe it
        query = cv2.imread(Query)
        features = cd.gabour(query)
        # perform the search
        searcher = Searcher(IndexFile)
        self.results = searcher.search(features)
        self.ResultList=list()
        # loop over the results

    def GetImageList(self):
        for (score, resultID) in self.results:
            # load the result image and display it
            self.ResultList.append(resultID)
            result = cv2.imread( resultID)
            #print("-------->",result)
            #if (not result):continue

            #cv2.imshow("Result", result)
            #cv2.waitKey(5000)
        return self.ResultList
